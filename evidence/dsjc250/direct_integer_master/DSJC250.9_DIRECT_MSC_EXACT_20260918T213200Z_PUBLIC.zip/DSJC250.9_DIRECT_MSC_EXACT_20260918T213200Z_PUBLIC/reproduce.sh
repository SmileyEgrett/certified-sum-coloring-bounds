#!/usr/bin/env bash
# Standalone Linux reproduction. Requires bash, GCC, CMake, coreutils, rg, time.
# Usage: bash reproduce.sh /absolute/new/output/directory single_free_cpu_number
set -euo pipefail
bundle=$(cd "$(dirname "$0")" && pwd)
[[ $# -ge 2 && $# -le 3 ]]
destination=$(realpath -m "$1")
one_cpu=$2
[[ "$one_cpu" =~ ^[0-9]+$ ]]
if [[ "${3:-}" != --pinned ]]; then
 exec taskset -c "$one_cpu" bash "$bundle/reproduce.sh" "$destination" "$one_cpu" --pinned
fi
[[ ! -e "$destination" ]]
cd "$bundle"
sha256sum --check --quiet SHA256SUMS
mkdir -p "$destination"/{build,bin,model,results,logs,manifest}
mkdir -p "$destination/source"
archive="$destination/source/HiGHS-v1.11.0.tar.gz"
curl --fail --location --silent --show-error --retry 3 --max-time 180 \
  https://codeload.github.com/ERGO-Code/HiGHS/tar.gz/refs/tags/v1.11.0 --output "$archive"
printf '2b44b074cf41439325ce4d0bbdac2d51379f56faf17ba15320a410d3c1f07275  %s\n' "$archive" | sha256sum --check --strict
tar -xzf "$archive" -C "$destination/source"
ulimit -v 4194304
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 BLIS_NUM_THREADS=1 OMP_DYNAMIC=FALSE
{
 date --iso-8601=seconds
 printf 'bundle=%s\noutput=%s\ncpu=%s\nthreads=1\nvirtual_memory_kib=4194304\ntime_limit=none\n' "$bundle" "$destination" "$one_cpu"
 sha256sum SHA256SUMS
 g++ --version
 cmake --version
} > "$destination/manifest/execution.txt"
cmake -S "$destination/source/HiGHS-1.11.0" -B "$destination/build/highs" \
 -DCMAKE_C_COMPILER=gcc -DCMAKE_CXX_COMPILER=g++ \
 -DCMAKE_BUILD_TYPE=Release -DBUILD_SHARED_LIBS=OFF -DBUILD_TESTING=OFF \
 -DBUILD_EXAMPLES=OFF -DZLIB=OFF -DFORTRAN=OFF -DCSHARP=OFF \
 > "$destination/logs/configure.stdout" 2> "$destination/logs/configure.stderr"
cmake --build "$destination/build/highs" --parallel 1 \
 > "$destination/logs/build.stdout" 2> "$destination/logs/build.stderr"
for component in prepare check; do
 g++ -std=c++20 -O2 -Wall -Wextra -Wpedantic "$bundle/source_snapshot/$component.cpp" \
  -o "$destination/bin/$component" > "$destination/logs/build_$component.stdout" 2> "$destination/logs/build_$component.stderr"
done
g++ -std=c++20 -O2 -Wall -Wextra -Wpedantic \
 -I"$destination/source/HiGHS-1.11.0/highs" -I"$destination/build/highs" \
 "$bundle/source_snapshot/solve.cpp" "$destination/build/highs/lib/libhighs.a" -lpthread \
 -o "$destination/bin/solve" > "$destination/logs/build_solve.stdout" 2> "$destination/logs/build_solve.stderr"
"$destination/bin/prepare" --self-test > "$destination/results/selftest.txt"
"$destination/bin/prepare" "$bundle/input/DSJC250.9.col" "$destination/model" > "$destination/results/generation.txt"
"$destination/bin/check" "$bundle/input/DSJC250.9.col" "$destination/model/stable_sets.tsv" "$destination/model/master.mps" > "$destination/results/input_model_verification.txt"
cmp "$destination/model/stable_sets.tsv" "$bundle/results/generated/stable_sets.tsv"
cmp "$destination/model/master.mps" "$bundle/results/generated/master.mps"
for job in lp mip01 mip02; do
 if [[ "$job" == lp ]]; then mode=lp; else mode=mip; fi
 mkdir "$destination/results/$job"
 /usr/bin/time -v -o "$destination/logs/$job.resources" \
  "$destination/bin/solve" "$destination/model/master.mps" "$mode" "$destination/results/$job/solve" \
  > "$destination/logs/$job.stdout" 2> "$destination/logs/$job.stderr"
 if [[ "$mode" == mip ]]; then
  "$destination/bin/check" "$bundle/input/DSJC250.9.col" "$destination/model/stable_sets.tsv" \
   "$destination/model/master.mps" "$destination/results/$job/solve.columns.tsv" \
   "$destination/results/$job/verified" > "$destination/results/$job/verification.txt"
 fi
done
date --iso-8601=seconds > "$destination/manifest/completed.txt"
cd "$destination"
rg --files -g '!build/**' -g '!SHA256SUMS' | LC_ALL=C sort | xargs sha256sum > SHA256SUMS
sha256sum --check --quiet SHA256SUMS
printf 'Completed. Results: %s\n' "$destination/results"
