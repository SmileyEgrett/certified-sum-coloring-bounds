# DSJC250.9 complete-master static evidence

This package contains the source, complete stable-set universe, master model,
original LP/MIP results and solver stdout/resource logs for two HiGHS 1.11.0
runs. `MODEL.md` defines the formulation and `SUMMARY.txt` records the
numerical outcomes.

The checked model has 6555 stable sets, 255 equations and 7125 variables.
Both returned proper colorings have sum 8277. HiGHS's status is conventional
floating-point MIP evidence, not an independently replayable MIP lower proof.
The exact lower proof is supplied by the separate threshold/conditional
package in the companion repository.

The outer package's `materialize.sh` authenticates and installs the external
graph. `SHA256SUMS` binds all files required for static replay, including
that graph as `input/DSJC250.9.col`.

Optional `bash reproduce.sh NEW_OUTPUT CPU` fetches pinned public HiGHS
source with its upstream notices, builds it on one CPU, and repeats the LP
and two integer solves. It requires network retrieval, curl, CMake, GCC/C++20,
coreutils/taskset, ripgrep and time. Static verification needs no HiGHS.

Original code is MIT-licensed; original documentation and research data are
CC BY 4.0. See [license scope and third-party notices](LICENSES.md).
