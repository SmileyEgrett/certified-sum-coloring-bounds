# Licenses

Copyright (c) 2026 Olawale Titiloye for the author's original contributions.

Original code in `source_snapshot/` and the `reproduce.sh` script are licensed
under the [MIT License](LICENSE-MIT). Original documentation and generated
research records, including the model and witness data, are licensed under
[CC BY 4.0](LICENSE-CC-BY-4.0), to the extent copyright or similar rights apply.
These licenses apply to different components, not as alternatives for all files.

Third-party material retains its own notices and terms. HiGHS source is fetched
separately by the optional rerun recipe with its upstream and third-party
notices; no solver binary or vendor tree is included here. The benchmark graph
is also fetched and checked separately. These terms grant no additional rights
in third-party material.
